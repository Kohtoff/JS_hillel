# JS home work structure

1. You need to install Node.js from https://nodejs.org
2. Create new folder with your project
3. Copy all files from this repo to your project (exclude README.md and LICENSE)
4. In terminal - git init (inside folder with your current project)
5. In terminal - npm install
6. Write your code in src/index.js
7. Enjoy!

P.S. If you use VS Code you can install plugin 'Prettier - Code formatter' and turn on 'Format On Save' in VS Code settings
